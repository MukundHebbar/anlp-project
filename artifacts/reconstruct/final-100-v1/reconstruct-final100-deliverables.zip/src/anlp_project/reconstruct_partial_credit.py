"""Versioned PC-v1 aggregation; uncertain/missing judgments stay unscored."""

DIMENSIONS = (
    ('fidelity', 'premise_fidelity'),
    ('fidelity', 'target_fidelity'),
    ('validity', 'evidence_integration'),
    ('validity', 'mathematical_validity'),
)


def aggregate(fidelity=None, validity=None):
    judgments = {'fidelity': fidelity or {}, 'validity': validity or {}}
    dimensions = {}
    for role, name in DIMENSIONS:
        value = judgments[role].get(name, {}).get('score')
        if value is not None and (type(value) is not int or not 0 <= value <= 4):
            raise ValueError('Invalid dimension score: ' + name)
        dimensions[name] = value
    known = [v for v in dimensions.values() if v is not None]
    lower = 6.25 * sum(known)
    upper = lower + 25 * (4 - len(known))
    shortcut = judgments['validity'].get('shortcut', {}).get('present')
    if shortcut is not None and type(shortcut) is not bool:
        raise ValueError('Shortcut status must be Boolean or unresolved')
    raw = lower if len(known) == 4 else None
    resolved = (len(known) == 4 and shortcut is False
                and all(judgments[role].get('status') == 'scored' for role in judgments))
    if shortcut is True:
        score, bounds, reason = 0.0, [0.0, 0.0], 'known_shortcut'
    elif resolved:
        score, bounds, reason = raw, [raw, raw], None
    else:
        score, bounds, reason = None, [0.0 if shortcut is None else lower, upper], 'unresolved_judgment'
    return {
        'version': 'RECONSTRUCT-PC-v1', 'dimensions': dimensions,
        'raw_dimension_total': raw, 'shortcut': shortcut,
        'score_100': score, 'score_bounds': bounds, 'reason': reason,
        'rating_1_to_5': min(5, int(score // 20) + 1) if score is not None else None,
    }
